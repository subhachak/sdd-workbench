"""
app.py — FastAPI routes only. No business logic, no prompts.
Phase 1: sequential agent calls.
Phase 2: replace /api/run with /api/run/stream (SSE + LangGraph).
"""

import os
import webbrowser
import threading
import logging
from pathlib import Path
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

from graph.state import initial_state
from agents import spec_analyst, code_builder, test_writer, drift_monitor
from agents.code_builder import MAX_ITERATIONS

load_dotenv()
logging.basicConfig(level=logging.INFO, format="  %(levelname)s  %(message)s")
logger = logging.getLogger("sdd.app")

app = FastAPI(title="Brillio SDD Workbench")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

static_dir = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=static_dir), name="static")


class SDDRequest(BaseModel):
    spec: str
    language: str = "Python"
    test_framework: str = "pytest"


@app.get("/")
def index():
    return FileResponse(static_dir / "index.html")


@app.get("/health")
def health():
    return {"status": "ok", "api_key_configured": bool(os.getenv("ANTHROPIC_API_KEY"))}


@app.post("/api/run")
async def run_sdd(req: SDDRequest):
    if not os.getenv("ANTHROPIC_API_KEY"):
        raise HTTPException(500, "ANTHROPIC_API_KEY not set — add to .env and restart")

    logger.info(f"Pipeline start  lang={req.language}  framework={req.test_framework}  spec={len(req.spec)}chars")

    state = initial_state(req.spec, req.language, req.test_framework)

    # Step 1: Spec Analyst
    state = await spec_analyst.run(state)
    if state["status"] == "error":
        raise HTTPException(500, state["error_message"])

    # Step 2: Code Builder with lint retry
    for _ in range(MAX_ITERATIONS):
        state = await code_builder.run(state)
        if state["status"] == "error":
            raise HTTPException(500, state["error_message"])
        if state["lint_passed"]:
            break
    if not state["lint_passed"]:
        logger.warning(f"Lint still failing after {MAX_ITERATIONS} iterations — proceeding")

    # Step 3: Test Writer
    state = await test_writer.run(state)
    if state["status"] == "error":
        raise HTTPException(500, state["error_message"])

    # Step 4: Drift Monitor
    state = await drift_monitor.run(state)
    if state["status"] == "error":
        raise HTTPException(500, state["error_message"])

    logger.info(f"Pipeline done  iterations={state['iteration_count']}  lint_passed={state['lint_passed']}")

    return {
        "spec_breakdown":            state["spec_breakdown"],
        "spec_completeness_comment": state["spec_completeness_comment"],
        "implementation":            state["implementation"],
        "tests":                     state["tests"],
        "drift_analysis":            state["drift_analysis"],
        "_meta": {
            "iterations":   state["iteration_count"],
            "lint_passed":  state["lint_passed"],
            "lint_errors":  state["lint_result"]["errors"] if state.get("lint_result") else [],
        },
    }


def _open_browser():
    import time; time.sleep(1.2)
    webbrowser.open(f"http://localhost:{os.getenv('PORT', '8000')}")


if __name__ == "__main__":
    port = int(os.getenv("PORT", "8000"))
    key  = os.getenv("ANTHROPIC_API_KEY", "")

    print(f"\n  Brillio SDD Workbench  →  http://localhost:{port}")
    print(f"  API key: {'✓ loaded' if key else '✗ NOT SET — edit .env'}\n")

    threading.Thread(target=_open_browser, daemon=True).start()
    try:
        uvicorn.run(app, host="0.0.0.0", port=port, log_level="info")
    except OSError:
        print(f"  Port {port} in use — try: PORT=8001 python app.py")
